package com.project.it;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectitApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectitApplication.class, args);
        System.out.println("Project IT START++++++++");
    }

}
